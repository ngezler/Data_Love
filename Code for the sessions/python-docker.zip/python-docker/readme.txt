run these commands to get an output:
docker build --tag python-docker .
docker run -d -p 5000:5000 python-docker
