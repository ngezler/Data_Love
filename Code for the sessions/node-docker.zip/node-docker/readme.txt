run these commands to get an output:
docker build --tag node-docker .
docker run -d -p 3000:3000 node-docker
